// Cada ferramenta define tudo que é necessário para:
// 1) aparecer no select menu do painel
// 2) montar o container da sessão dentro da thread/canal
// 3) saber quais extensões aceitar e como converter o arquivo
module.exports = {
  conversor: {
    id: 'conversor',
    emojiKey: 'reload',
    label: 'Conversor',
    menuDescription: 'Transforme seu vídeo em GIF',
    panelTitle: 'Conversor de Vídeo para GIF',
    formatosAceitos: ['.mp4', '.wmv', '.flv', '.mov'],
    tamanhoRecomendado: '10MB',
    kind: 'video-to-gif'
  },
  compressor: {
    id: 'compressor',
    emojiKey: 'cardbox',
    label: 'Compressor',
    menuDescription: 'Diminua o tamanho do seu GIF',
    panelTitle: 'Compressor de Mídia',
    formatosAceitos: ['.gif', '.mp4', '.mov'],
    tamanhoRecomendado: '25MB',
    kind: 'compress'
  },
  extrator: {
    id: 'extrator',
    emojiKey: 'cloud',
    label: 'Extrator',
    menuDescription: 'Extraia o áudio de vídeos',
    panelTitle: 'Extrator de Áudio',
    formatosAceitos: ['.mp4', '.mov', '.mkv', '.webm'],
    tamanhoRecomendado: '25MB',
    kind: 'extract-audio'
  },
  pretoEBranco: {
    id: 'pretoEBranco',
    emojiKey: 'colors',
    label: 'Preto e Branco',
    menuDescription: 'Deixe sua imagem em preto e branco',
    panelTitle: 'Filtro Preto e Branco',
    formatosAceitos: ['.png', '.jpg', '.jpeg', '.webp', '.gif'],
    tamanhoRecomendado: '10MB',
    kind: 'grayscale'
  }
};
