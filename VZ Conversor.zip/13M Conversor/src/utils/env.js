require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');

const CONFIG_JSON_PATH = path.join(__dirname, '..', '..', 'config.json');
const ENV_PATH = path.join(__dirname, '..', '..', '.env');

function loadFromConfigJson() {
  if (!fs.existsSync(CONFIG_JSON_PATH)) return {};
  try {
    const raw = fs.readFileSync(CONFIG_JSON_PATH, 'utf8');
    return JSON.parse(raw);
  } catch {
    console.warn('⚠ config.json existe mas não pôde ser lido/parseado (JSON inválido).');
    return {};
  }
}

function clean(value) {
  if (typeof value !== 'string') return value || null;
  const trimmed = value.trim();
  return trimmed === '' ? null : trimmed;
}

const fileConfig = loadFromConfigJson();

// Aceita alguns nomes alternativos comuns em painéis de hospedagem,
// caso a variável tenha sido criada com outro nome.
const DISCORD_TOKEN = clean(
  process.env.DISCORD_TOKEN ||
    process.env.TOKEN ||
    process.env.BOT_TOKEN ||
    fileConfig.token
);
const CLIENT_ID = clean(
  process.env.CLIENT_ID ||
    process.env.CLIENTID ||
    process.env.APPLICATION_ID ||
    fileConfig.clientId
);
const GUILD_ID = clean(
  process.env.GUILD_ID ||
    process.env.GUILDID ||
    process.env.SERVER_ID ||
    fileConfig.guildId
);

const missing = [];
if (!DISCORD_TOKEN) missing.push('DISCORD_TOKEN');
if (!CLIENT_ID) missing.push('CLIENT_ID');
if (!GUILD_ID) missing.push('GUILD_ID');

if (missing.length > 0) {
  console.error(`✗ Faltando: ${missing.join(', ')}\n`);

  console.error('Onde eu procurei:');
  console.error(
    `  • Variáveis de ambiente do processo (process.env): ${
      Object.keys(process.env).some((k) =>
        ['DISCORD_TOKEN', 'TOKEN', 'BOT_TOKEN', 'CLIENT_ID', 'CLIENTID', 'APPLICATION_ID', 'GUILD_ID', 'GUILDID', 'SERVER_ID'].includes(k)
      )
        ? 'encontrei ALGUMA coisa, mas incompleta — confira nomes/valores acima'
        : 'nenhuma dessas variáveis está definida aqui'
    }`
  );
  console.error(
    `  • Arquivo .env em ${ENV_PATH}: ${fs.existsSync(ENV_PATH) ? 'existe' : 'NÃO existe'}`
  );
  console.error(
    `  • Arquivo config.json em ${CONFIG_JSON_PATH}: ${fs.existsSync(CONFIG_JSON_PATH) ? 'existe' : 'NÃO existe'}`
  );

  console.error(
    '\n→ Se você está usando um painel de hospedagem (Discloud, SquareCloud, Railway, Pterodactyl, etc.), ' +
      'o mais comum é precisar cadastrar essas 3 variáveis na aba de "Variáveis de Ambiente" / "Environment Variables" ' +
      'do painel — um arquivo .env sozinho às vezes não é lido automaticamente por esses hosts. ' +
      'Me diga qual host você está usando que eu te falo exatamente onde configurar.'
  );

  process.exit(1);
}

module.exports = { DISCORD_TOKEN, CLIENT_ID, GUILD_ID };
