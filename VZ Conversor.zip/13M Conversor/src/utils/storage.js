const fs = require('fs');
const path = require('path');
const DEFAULT_TOOLS = require('./tools');
const { getEmoji } = require('../services/emojiManager');

const DB_PATH = path.join(__dirname, '..', '..', 'data', 'guilds.json');

function ensureFile() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({}, null, 2));
  }
}

function readAll() {
  ensureFile();
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function writeAll(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

const DEFAULT_PANEL_TITLE = 'Conversor de Arquivos';
const DEFAULT_PANEL_TEXT =
  'Bem-vindo à Central de Conversão. Este módulo oferece ferramentas de alto desempenho para edição, otimização e processamento de arquivos diretamente via Discord.';
const DEFAULT_PLACEHOLDER = 'Selecione o que deseja fazer...';

function defaultConfig() {
  return {
    panelTitle: DEFAULT_PANEL_TITLE,
    panelText: DEFAULT_PANEL_TEXT,
    placeholder: DEFAULT_PLACEHOLDER,
    bannerUrl: null,
    thumbnailUrl: null,
    logChannelId: null,
    areaId: null, // ID da categoria (modo Canal) ou do canal (modo Tópico)
    areaType: 'channel', // 'category' -> cria canais | 'channel' -> cria tópicos (thread)
    panelChannelId: null,
    panelMessageId: null,
    tools: {}, // overrides por ferramenta: { [toolId]: { label, panelTitle, emoji, menuDescription, formatosAceitos } }
    sessions: {} // threadOrChannelId -> { userId, option, areaId, mode }
  };
}

function getGuildConfig(guildId) {
  const all = readAll();
  if (!all[guildId]) {
    all[guildId] = defaultConfig();
    writeAll(all);
  } else {
    // Garante compatibilidade caso novos campos sejam adicionados depois
    const merged = { ...defaultConfig(), ...all[guildId] };
    merged.tools = { ...(all[guildId].tools || {}) };
    merged.sessions = { ...(all[guildId].sessions || {}) };
    all[guildId] = merged;
  }
  return all[guildId];
}

function setGuildConfig(guildId, patch) {
  const all = readAll();
  const current = getGuildConfig(guildId);
  all[guildId] = { ...current, ...patch };
  writeAll(all);
  return all[guildId];
}

function resetGuildConfig(guildId) {
  const all = readAll();
  all[guildId] = defaultConfig();
  writeAll(all);
  return all[guildId];
}

// Retorna as ferramentas já mescladas com os overrides salvos pelo admin
function getEffectiveTools(guildId) {
  const cfg = getGuildConfig(guildId);
  const result = {};
  for (const [id, tool] of Object.entries(DEFAULT_TOOLS)) {
    const override = cfg.tools[id] || {};
    result[id] = {
      ...tool,
      emoji: getEmoji(tool.emojiKey),
      ...override
    };
  }
  return result;
}

function getEffectiveTool(guildId, toolId) {
  const cfg = getGuildConfig(guildId);
  const base = DEFAULT_TOOLS[toolId];
  if (!base) return null;
  return {
    ...base,
    emoji: getEmoji(base.emojiKey),
    ...(cfg.tools[toolId] || {})
  };
}

function setToolOverride(guildId, toolId, patch) {
  const all = readAll();
  const cfg = getGuildConfig(guildId);
  cfg.tools[toolId] = { ...(cfg.tools[toolId] || {}), ...patch };
  all[guildId] = cfg;
  writeAll(all);
  return cfg.tools[toolId];
}

function addSession(guildId, channelId, sessionData) {
  const all = readAll();
  const cfg = getGuildConfig(guildId);
  cfg.sessions[channelId] = sessionData;
  all[guildId] = cfg;
  writeAll(all);
}

function removeSession(guildId, channelId) {
  const all = readAll();
  const cfg = getGuildConfig(guildId);
  const session = cfg.sessions[channelId];
  delete cfg.sessions[channelId];
  all[guildId] = cfg;
  writeAll(all);
  return session;
}

function getSession(guildId, channelId) {
  const cfg = getGuildConfig(guildId);
  return cfg.sessions[channelId] || null;
}

// Point 2: impede que o mesmo usuário abra mais de uma sessão ao mesmo tempo
function findActiveSessionForUser(guildId, userId) {
  const cfg = getGuildConfig(guildId);
  for (const [channelId, session] of Object.entries(cfg.sessions)) {
    if (session.userId === userId) {
      return { channelId, session };
    }
  }
  return null;
}

// Point 3: fechamento automático por inatividade
function touchSessionActivity(guildId, channelId) {
  const all = readAll();
  const cfg = getGuildConfig(guildId);
  if (!cfg.sessions[channelId]) return;
  cfg.sessions[channelId].lastActivity = Date.now();
  all[guildId] = cfg;
  writeAll(all);
}

function getAllSessionEntries(guildId) {
  const cfg = getGuildConfig(guildId);
  return Object.entries(cfg.sessions).map(([channelId, session]) => ({
    channelId,
    session
  }));
}

module.exports = {
  findActiveSessionForUser,
  touchSessionActivity,
  getAllSessionEntries,
  getGuildConfig,
  setGuildConfig,
  resetGuildConfig,
  getEffectiveTools,
  getEffectiveTool,
  setToolOverride,
  addSession,
  removeSession,
  getSession,
  DEFAULT_PANEL_TEXT,
  DEFAULT_PANEL_TITLE,
  DEFAULT_PLACEHOLDER
};
