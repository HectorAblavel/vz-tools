// Roda checagens rápidas via REST (sem abrir conexão de gateway) para
// isolar rapidamente por que o bot "não liga":
// token errado, client ID errado, bot não está no servidor, etc.
const { REST, Routes } = require('discord.js');
const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = require('./utils/env');

const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);

async function main() {
  console.log('◎ Verificando credenciais...\n');

  // 1) O token é válido?
  try {
    const me = await rest.get(Routes.user('@me'));
    console.log(`✓ Token válido. Bot: ${me.username}#${me.discriminator ?? '0'} (ID: ${me.id})`);

    if (me.id !== CLIENT_ID) {
      console.warn(
        `⚠ Atenção: o CLIENT_ID configurado (${CLIENT_ID}) é diferente do ID real do bot (${me.id}). ` +
          'Corrija o CLIENT_ID no .env/config.json.'
      );
    }
  } catch (error) {
    console.error('✗ Token inválido ou expirado. Detalhes:', error.message);
    console.error(
      '→ Gere um novo token em https://discord.com/developers/applications > sua aplicação > Bot > Reset Token.'
    );
    process.exit(1);
  }

  // 2) O bot está no servidor configurado (GUILD_ID)?
  try {
    const guild = await rest.get(Routes.guild(GUILD_ID));
    console.log(`✓ Bot está no servidor configurado: ${guild.name} (${guild.id})`);
  } catch (error) {
    console.error(`✗ O bot não está no servidor com GUILD_ID=${GUILD_ID} (ou o ID está errado).`);
    console.error(
      '→ Gere um link de convite em Developer Portal > sua aplicação > OAuth2 > URL Generator ' +
        '(escopos: bot, applications.commands) e adicione o bot no servidor certo.'
    );
    process.exit(1);
  }

  console.log('\n✓ Tudo certo! Pode rodar "npm run deploy" e depois "npm start".');
}

main().catch((error) => {
  console.error('✗ Erro inesperado no autodiagnóstico:', error);
  process.exit(1);
});
