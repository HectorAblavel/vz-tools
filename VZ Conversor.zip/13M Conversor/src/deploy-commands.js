const { REST, Routes } = require('discord.js');
const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = require('./utils/env');
const config = require('./commands/config');

const commands = [config.data.toJSON()];

const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);

(async () => {
  try {
    console.log(`Registrando slash commands apenas no servidor ${GUILD_ID}...`);
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
      body: commands
    });
    console.log('✓ Comandos registrados com sucesso (somente nesse servidor).');
  } catch (error) {
    console.error('✗ Erro ao registrar comandos:', error);
  }
})();
