const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  MessageFlags
} = require('discord.js');

const { buildHomeContainer } = require('../components/adminBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botconfig')
    .setDescription('Abre o painel administrativo do Conversor de Arquivos')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    await interaction.reply({
      components: [buildHomeContainer(interaction.guildId)],
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
    });
  }
};
