const fs = require('node:fs');
const path = require('node:path');
const { Client, Collection, GatewayIntentBits, Partials, REST, Routes } = require('discord.js');

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = require('./utils/env');
const { handleSelectTool } = require('./handlers/selectMenu');
const { handleCloseSession } = require('./handlers/button');
const { handleAdminButton } = require('./handlers/adminButton');
const {
  handleSelectToolEdit,
  handleSelectLogChannel,
  handleSelectAreaChannel
} = require('./handlers/adminSelect');
const {
  handleTextosModal,
  handleBannerThumbModal,
  handleToolEditModal
} = require('./handlers/adminModal');
const { handlePotentialFileUpload } = require('./handlers/messageCreate');
const { startInactivitySweep } = require('./services/inactivitySweep');
const { syncEmojis } = require('./services/emojiManager');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel, Partials.Message]
});

// Carrega os slash commands da pasta commands/
client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

// Bot privado: garante que ele só fica no servidor configurado
async function enforcePrivateGuild() {
  for (const [id, guild] of client.guilds.cache) {
    if (id !== GUILD_ID) {
      console.warn(`⚠ Saindo do servidor não autorizado: ${guild.name} (${id})`);
      await guild.leave().catch(() => {});
    }
  }
}

// Registra os slash commands sozinho ao ligar — assim não depende de rodar
// "npm run deploy" manualmente (muitos painéis de hospedagem só executam
// "npm start", e é por isso que o /botconfig não aparecia).
async function registerCommandsAutomatically() {
  try {
    const commandsData = client.commands.map((cmd) => cmd.data.toJSON());
    const rest = new REST({ version: '10' }).setToken(DISCORD_TOKEN);
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
      body: commandsData
    });
    console.log(`✓ Slash commands registrados no servidor ${GUILD_ID} (/botconfig).`);
  } catch (error) {
    console.error('✗ Não consegui registrar os slash commands automaticamente:', error.message);
    console.error(
      '→ Confira se o CLIENT_ID está certo e se o bot foi convidado com o escopo "applications.commands".'
    );
  }
}

client.once('clientReady', async () => {
  console.log(`✓ Bot online como ${client.user.tag}`);
  await enforcePrivateGuild();
  await syncEmojis(client, DISCORD_TOKEN);
  await registerCommandsAutomatically();
  startInactivitySweep(client, GUILD_ID);
});

client.on('guildCreate', async (guild) => {
  if (guild.id !== GUILD_ID) {
    console.warn(`⚠ Bot foi adicionado a um servidor não autorizado: ${guild.name} (${guild.id}). Saindo...`);
    await guild.leave().catch(() => {});
  }
});

client.on('interactionCreate', async (interaction) => {
  // Bot privado: ignora qualquer interação fora do servidor configurado
  if (interaction.guildId && interaction.guildId !== GUILD_ID) return;

  try {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction);
      return;
    }

    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'conversor:select-tool') {
        return handleSelectTool(interaction);
      }
      if (interaction.customId === 'botconfig:select-tool-edit') {
        return handleSelectToolEdit(interaction);
      }
      return;
    }

    if (interaction.isChannelSelectMenu()) {
      if (interaction.customId === 'botconfig:select-log-channel') {
        return handleSelectLogChannel(interaction);
      }
      if (interaction.customId === 'botconfig:select-area-channel') {
        return handleSelectAreaChannel(interaction);
      }
      return;
    }

    if (interaction.isButton()) {
      if (interaction.customId === 'conversor:close-session') {
        return handleCloseSession(interaction);
      }
      if (interaction.customId.startsWith('botconfig:')) {
        return handleAdminButton(interaction);
      }
      return;
    }

    if (interaction.isModalSubmit()) {
      if (interaction.customId === 'botconfig:textos-modal') {
        return handleTextosModal(interaction);
      }
      if (interaction.customId === 'botconfig:banner-thumb-modal') {
        return handleBannerThumbModal(interaction);
      }
      if (interaction.customId.startsWith('botconfig:tool-edit-modal:')) {
        const toolId = interaction.customId.split(':')[2];
        return handleToolEditModal(interaction, toolId);
      }
      return;
    }
  } catch (error) {
    console.error('Erro ao processar interação:', error);
    const errorPayload = {
      content: '✗ Ocorreu um erro ao processar essa ação.',
      flags: 64 // Ephemeral
    };
    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp(errorPayload);
      } else {
        await interaction.reply(errorPayload);
      }
    } catch {
      // interação pode já ter expirado, sem problema
    }
  }
});

client.on('messageCreate', async (message) => {
  if (message.guildId && message.guildId !== GUILD_ID) return;
  try {
    await handlePotentialFileUpload(message);
  } catch (error) {
    console.error('Erro ao processar upload de arquivo:', error);
  }
});

// Loga qualquer erro de conexão do client sem derrubar o processo
client.on('error', (error) => {
  console.error('✗ Erro no client do Discord:', error);
});
client.on('shardError', (error) => {
  console.error('✗ Erro no shard:', error);
});
client.on('warn', (info) => {
  console.warn('⚠ Aviso do discord.js:', info);
});

// Rede de segurança: se algo não tratado acontecer, LOGA em vez de matar o
// processo em silêncio. Sem isso, um erro de login (token errado, intents
// privilegiadas desativadas no portal etc.) derruba o bot ANTES do "ready"
// aparecer, e parece que o bot "não liga".
process.on('unhandledRejection', (error) => {
  console.error('✗ Promessa rejeitada sem tratamento:', error);
});
process.on('uncaughtException', (error) => {
  console.error('✗ Exceção não capturada:', error);
});

console.log('⏻ Conectando ao Discord...');

client.login(DISCORD_TOKEN).catch((error) => {
  console.error('✗ Falha ao logar no Discord. O bot NÃO vai ficar online.');
  console.error('Causa reportada:', error.message);

  if (error.message?.includes('An invalid token was provided')) {
    console.error(
      '→ O DISCORD_TOKEN está errado ou expirado. Gere um novo em ' +
        'https://discord.com/developers/applications > sua aplicação > Bot > Reset Token.'
    );
  } else if (error.message?.includes('disallowed intents')) {
    console.error(
      '→ Faltou ativar as Privileged Gateway Intents. Vá em ' +
        'https://discord.com/developers/applications > sua aplicação > Bot e ' +
        'ative "MESSAGE CONTENT INTENT" e "SERVER MEMBERS INTENT".'
    );
  }

  process.exit(1);
});
