const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { AttachmentBuilder } = require('discord.js');

const { getSession, getEffectiveTool, touchSessionActivity } = require('../utils/storage');
const { convert } = require('../services/converter');

// Melhoria 4: limite de tamanho antes de baixar/processar (padrão: 25MB)
const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024;

async function downloadAttachment(url, destPath) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Falha ao baixar o arquivo (status ${res.status}).`);
  }
  const arrayBuffer = await res.arrayBuffer();
  await fs.writeFile(destPath, Buffer.from(arrayBuffer));
}

async function safeUnlink(filePath) {
  try {
    await fs.unlink(filePath);
  } catch {
    // arquivo já pode não existir, tudo bem
  }
}

function formatBytes(bytes) {
  const mb = bytes / (1024 * 1024);
  return `${mb.toFixed(1)}MB`;
}

async function processSingleAttachment(message, attachment, tool) {
  const ext = path.extname(attachment.name || '').toLowerCase();

  if (!tool.formatosAceitos.includes(ext)) {
    await message.reply({
      content:
        `✗ **${attachment.name}**: formato não aceito para **${tool.label}**.\n` +
        `Formatos aceitos: ${tool.formatosAceitos.map((f) => `\`${f}\``).join(', ')}`
    });
    return;
  }

  if (attachment.size > MAX_FILE_SIZE_BYTES) {
    await message.reply({
      content:
        `✗ **${attachment.name}** tem ${formatBytes(attachment.size)}, ` +
        `acima do limite de ${formatBytes(MAX_FILE_SIZE_BYTES)} para processamento.`
    });
    return;
  }

  const processingMsg = await message.reply({
    content: `⏳ Processando **${attachment.name}**, aguarde um momento...`
  });

  const workDir = await fs.mkdtemp(path.join(os.tmpdir(), 'conversor-'));
  const inputPath = path.join(workDir, `input${ext}`);

  const outputExtMap = {
    'video-to-gif': '.gif',
    compress: ext,
    'extract-audio': '.mp3',
    grayscale: ext === '.gif' ? '.gif' : ext
  };
  const outputExt = outputExtMap[tool.kind] || ext;
  const outputPath = path.join(workDir, `output${outputExt}`);

  try {
    await downloadAttachment(attachment.url, inputPath);
    await convert(tool.kind, inputPath, outputPath);

    const resultAttachment = new AttachmentBuilder(outputPath, {
      name: `resultado${outputExt}`
    });

    await processingMsg.edit({
      content: `✓ **${attachment.name}** processado com sucesso!`,
      files: [resultAttachment]
    });
  } catch (err) {
    await processingMsg.edit({
      content: `✗ Não foi possível converter **${attachment.name}**. Detalhes: \`${err.message}\``
    });
  } finally {
    await safeUnlink(inputPath);
    await safeUnlink(outputPath);
    await fs.rm(workDir, { recursive: true, force: true }).catch(() => {});
  }
}

async function handlePotentialFileUpload(message) {
  if (message.author.bot) return;
  if (!message.guild) return;

  const session = getSession(message.guild.id, message.channel.id);
  if (!session) return;
  if (message.author.id !== session.userId) return;

  // Qualquer mensagem do dono da sessão conta como atividade,
  // não só o envio de arquivo (evita fechar sessão em uso).
  touchSessionActivity(message.guild.id, message.channel.id);

  if (message.attachments.size === 0) return;

  const tool = getEffectiveTool(message.guild.id, session.option);
  if (!tool) return;

  // Melhoria 5: processa todos os anexos da mensagem, um de cada vez
  for (const attachment of message.attachments.values()) {
    await processSingleAttachment(message, attachment, tool);
  }
}

module.exports = { handlePotentialFileUpload };
