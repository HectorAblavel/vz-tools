const { MessageFlags } = require('discord.js');
const { getSession, removeSession } = require('../utils/storage');
const { logSessionClosed } = require('../services/logger');

// Núcleo do fechamento — usado tanto pelo botão "Fechar" quanto pelo
// fechamento automático por inatividade.
async function closeSession(guild, channel, session, closedByLabel) {
  removeSession(guild.id, channel.id);

  await logSessionClosed(guild, {
    areaId: session.areaId,
    closedByUserId: closedByLabel
  });

  // Tanto no modo Canal quanto no modo Tópico, fechar a sessão agora
  // apaga o canal/tópico de fato (antes, tópicos só eram trancados e
  // arquivados, ficando acumulados na lista de tópicos do servidor).
  await channel.delete('Sessão do conversor encerrada').catch(() => {});
}

async function handleCloseSession(interaction) {
  const guild = interaction.guild;
  const channel = interaction.channel;

  const session = getSession(guild.id, channel.id);

  if (!session) {
    await interaction.reply({
      content: '⚠ Essa sessão já não está mais ativa.',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  await interaction.reply({
    content: '⚿ Fechando a sessão do conversor...',
    flags: MessageFlags.Ephemeral
  });

  await closeSession(guild, channel, session, interaction.user.id);
}

module.exports = { handleCloseSession, closeSession };
