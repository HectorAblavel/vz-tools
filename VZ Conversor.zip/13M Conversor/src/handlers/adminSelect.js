const {
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ChannelType
} = require('discord.js');

const { getEffectiveTool, setGuildConfig } = require('../utils/storage');
const {
  buildHomeContainer,
  buildLogsCategoriaContainer
} = require('../components/adminBuilder');

// Select de string: escolher qual ferramenta editar (abre modal)
async function handleSelectToolEdit(interaction) {
  const toolId = interaction.values[0];
  const tool = getEffectiveTool(interaction.guildId, toolId);

  if (!tool) {
    await interaction.reply({
      content: '✗ Opção inválida.',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  const modal = new ModalBuilder()
    .setCustomId(`botconfig:tool-edit-modal:${toolId}`)
    .setTitle(`Editar ${tool.label}`);

  const label = new TextInputBuilder()
    .setCustomId('label')
    .setLabel('Label (nome no menu)')
    .setStyle(TextInputStyle.Short)
    .setValue(tool.label)
    .setMaxLength(80)
    .setRequired(true);

  const panelTitle = new TextInputBuilder()
    .setCustomId('panelTitle')
    .setLabel('Título exibido dentro da sessão')
    .setStyle(TextInputStyle.Short)
    .setValue(tool.panelTitle)
    .setMaxLength(100)
    .setRequired(true);

  // Precisa caber emojis customizados da aplicação, que vêm no formato
  // "<:nome:id>" (bem mais longo que um emoji unicode simples) — com
  // limite de 10 o modal quebrava (RangeError) sempre que o emoji
  // customizado já estava instalado.
  const emoji = new TextInputBuilder()
    .setCustomId('emoji')
    .setLabel('Emoji (unicode ou <:nome:id>)')
    .setStyle(TextInputStyle.Short)
    .setValue(tool.emoji)
    .setMaxLength(100)
    .setRequired(true);

  const descricao = new TextInputBuilder()
    .setCustomId('menuDescription')
    .setLabel('Descrição no menu')
    .setStyle(TextInputStyle.Short)
    .setValue(tool.menuDescription)
    .setMaxLength(100)
    .setRequired(true);

  const formatos = new TextInputBuilder()
    .setCustomId('formatosAceitos')
    .setLabel('Formatos aceitos (separados por vírgula)')
    .setStyle(TextInputStyle.Short)
    .setValue(tool.formatosAceitos.join(', '))
    .setMaxLength(200)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(label),
    new ActionRowBuilder().addComponents(panelTitle),
    new ActionRowBuilder().addComponents(emoji),
    new ActionRowBuilder().addComponents(descricao),
    new ActionRowBuilder().addComponents(formatos)
  );

  await interaction.showModal(modal);
}

// Select de canal: define o canal de logs
async function handleSelectLogChannel(interaction) {
  const canal = interaction.channels.first();
  setGuildConfig(interaction.guildId, { logChannelId: canal.id });

  await interaction.update({
    components: [buildLogsCategoriaContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

// Select de canal: define a área (categoria ou canal) onde as sessões nascem
async function handleSelectAreaChannel(interaction) {
  const canal = interaction.channels.first();
  const areaType = canal.type === ChannelType.GuildCategory ? 'category' : 'channel';

  setGuildConfig(interaction.guildId, { areaId: canal.id, areaType });

  await interaction.update({
    components: [buildLogsCategoriaContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

module.exports = {
  handleSelectToolEdit,
  handleSelectLogChannel,
  handleSelectAreaChannel
};
