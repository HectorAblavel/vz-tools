const {
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder
} = require('discord.js');

const {
  getGuildConfig,
  setGuildConfig,
  resetGuildConfig
} = require('../utils/storage');

const {
  buildHomeContainer,
  buildPersonalizacaoContainer,
  buildOpcoesContainer,
  buildLogsCategoriaContainer,
  buildResetConfirmContainer
} = require('../components/adminBuilder');

const { buildPanelContainer } = require('../components/panelBuilder');

async function updateToHome(interaction) {
  await interaction.update({
    components: [buildHomeContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

async function updateToPersonalizar(interaction) {
  await interaction.update({
    components: [buildPersonalizacaoContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

async function updateToOpcoes(interaction) {
  await interaction.update({
    components: [buildOpcoesContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

async function updateToLogsCategoria(interaction) {
  await interaction.update({
    components: [buildLogsCategoriaContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

async function handleAdminButton(interaction) {
  const action = interaction.customId.split(':')[1];

  switch (action) {
    case 'home':
      return updateToHome(interaction);

    case 'personalizar':
      return updateToPersonalizar(interaction);

    case 'opcoes':
      return updateToOpcoes(interaction);

    case 'logs-categoria':
      return updateToLogsCategoria(interaction);

    case 'fechar':
      await interaction.update({
        content: 'Painel fechado.',
        components: [],
        flags: MessageFlags.IsComponentsV2
      });
      return;

    case 'usar-canal': {
      const cfg = getGuildConfig(interaction.guildId);
      const novoTipo = cfg.areaType === 'category' ? 'channel' : 'category';
      setGuildConfig(interaction.guildId, { areaType: novoTipo, areaId: null });
      await interaction.update({
        components: [buildHomeContainer(interaction.guildId)],
        flags: MessageFlags.IsComponentsV2
      });
      return;
    }

    case 'resetar': {
      // Melhoria 1: pede confirmação antes de resetar de verdade
      await interaction.update({
        components: [buildResetConfirmContainer()],
        flags: MessageFlags.IsComponentsV2
      });
      return;
    }

    case 'resetar-confirmar': {
      resetGuildConfig(interaction.guildId);
      await interaction.update({
        components: [buildHomeContainer(interaction.guildId)],
        flags: MessageFlags.IsComponentsV2
      });
      return;
    }

    case 'resetar-cancelar': {
      await updateToPersonalizar(interaction);
      return;
    }

    case 'enviar-painel': {
      const container = buildPanelContainer(interaction.guildId);
      const message = await interaction.channel.send({
        components: [container],
        flags: MessageFlags.IsComponentsV2
      });
      setGuildConfig(interaction.guildId, {
        panelChannelId: interaction.channel.id,
        panelMessageId: message.id
      });
      await interaction.reply({
        content: `✓ Painel enviado em ${interaction.channel}.`,
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    case 'textos': {
      const cfg = getGuildConfig(interaction.guildId);
      const modal = new ModalBuilder()
        .setCustomId('botconfig:textos-modal')
        .setTitle('Editar textos do painel');

      const titulo = new TextInputBuilder()
        .setCustomId('titulo')
        .setLabel('Título do painel')
        .setStyle(TextInputStyle.Short)
        .setValue(cfg.panelTitle)
        .setMaxLength(100)
        .setRequired(true);

      const placeholder = new TextInputBuilder()
        .setCustomId('placeholder')
        .setLabel('Placeholder do menu')
        .setStyle(TextInputStyle.Short)
        .setValue(cfg.placeholder)
        .setMaxLength(100)
        .setRequired(true);

      const descricao = new TextInputBuilder()
        .setCustomId('descricao')
        .setLabel('Descrição do painel')
        .setStyle(TextInputStyle.Paragraph)
        .setValue(cfg.panelText)
        .setMaxLength(1000)
        .setRequired(true);

      modal.addComponents(
        new ActionRowBuilder().addComponents(titulo),
        new ActionRowBuilder().addComponents(placeholder),
        new ActionRowBuilder().addComponents(descricao)
      );

      await interaction.showModal(modal);
      return;
    }

    case 'banner-thumb': {
      const cfg = getGuildConfig(interaction.guildId);
      const modal = new ModalBuilder()
        .setCustomId('botconfig:banner-thumb-modal')
        .setTitle('Editar banner e thumbnail');

      const banner = new TextInputBuilder()
        .setCustomId('banner')
        .setLabel('URL do banner (imagem grande)')
        .setStyle(TextInputStyle.Short)
        .setValue(cfg.bannerUrl || '')
        .setRequired(false);

      const thumb = new TextInputBuilder()
        .setCustomId('thumbnail')
        .setLabel('URL da thumbnail (imagem pequena)')
        .setStyle(TextInputStyle.Short)
        .setValue(cfg.thumbnailUrl || '')
        .setRequired(false);

      modal.addComponents(
        new ActionRowBuilder().addComponents(banner),
        new ActionRowBuilder().addComponents(thumb)
      );

      await interaction.showModal(modal);
      return;
    }

    default:
      await interaction.reply({
        content: '⚠ Ação desconhecida.',
        flags: MessageFlags.Ephemeral
      });
  }
}

module.exports = { handleAdminButton };
