const { ChannelType, MessageFlags, PermissionFlagsBits } = require('discord.js');
const {
  getGuildConfig,
  addSession,
  removeSession,
  getEffectiveTool,
  findActiveSessionForUser
} = require('../utils/storage');
const { buildSessionContainer } = require('../components/sessionBuilder');
const { logSessionCreated } = require('../services/logger');

function randomSuffix(length = 12) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let out = '';
  for (let i = 0; i < length; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

async function handleSelectTool(interaction) {
  const toolId = interaction.values[0];
  const guild = interaction.guild;
  const tool = getEffectiveTool(guild.id, toolId);

  if (!tool) {
    await interaction.reply({
      content: '✗ Opção inválida.',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  const cfg = getGuildConfig(guild.id);

  if (!cfg.areaId) {
    await interaction.reply({
      content:
        '⚠ Nenhuma área de criação foi configurada ainda. Peça a um administrador para rodar `/botconfig` e configurar em **Logs/Categoria**.',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  // Melhoria 2: um usuário só pode ter uma sessão ativa por vez
  const existing = findActiveSessionForUser(guild.id, interaction.user.id);
  if (existing) {
    await interaction.reply({
      content: `⚠ Você já tem uma sessão aberta em <#${existing.channelId}>. Feche-a antes de abrir outra.`,
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  const suffix = randomSuffix();
  const channelName = `conversor-${suffix}`;

  let createdChannel;
  let mode;

  try {
    if (cfg.areaType === 'category') {
      // Modo Canal: cria um canal de texto privado dentro da categoria
      createdChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: cfg.areaId,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: interaction.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.AttachFiles,
              PermissionFlagsBits.ReadMessageHistory
            ]
          }
        ]
      });
      mode = 'Canal';
    } else {
      // Modo Tópico: cria uma thread privada no canal configurado
      const parentChannel = await guild.channels.fetch(cfg.areaId);
      if (!parentChannel || !parentChannel.threads) {
        throw new Error('O canal configurado para criar tópicos não existe mais.');
      }
      createdChannel = await parentChannel.threads.create({
        name: channelName,
        type: ChannelType.PrivateThread,
        invitable: false,
        reason: `Sessão do conversor iniciada por ${interaction.user.tag}`
      });
      await createdChannel.members.add(interaction.user.id);
      mode = 'Tópico';
    }
  } catch (error) {
    console.error('✗ Falha ao criar canal/tópico da sessão:', error.message);
    await interaction.editReply({
      content:
        '✗ Não consegui criar sua sessão. A área configurada pode ter sido apagada ou o bot ' +
        'perdeu permissão nela. Peça a um administrador para reconferir em `/botconfig` → **Logs/Categoria**.'
    });
    return;
  }

  addSession(guild.id, createdChannel.id, {
    userId: interaction.user.id,
    option: tool.id,
    areaId: cfg.areaId,
    mode,
    lastActivity: Date.now()
  });

  const breadcrumb =
    mode === 'Tópico'
      ? `Conversor › ${tool.label}`
      : `${tool.label}`;

  const sessionContainer = buildSessionContainer({
    tool,
    userId: interaction.user.id,
    breadcrumb
  });

  try {
    await createdChannel.send({
      components: [sessionContainer],
      flags: MessageFlags.IsComponentsV2
    });
  } catch (error) {
    // Sem a mensagem inicial a sessão fica inutilizável — desfaz o registro
    // em vez de deixar uma sessão "fantasma" que bloqueia o usuário de
    // abrir outra (ver findActiveSessionForUser).
    console.error('✗ Falha ao enviar painel da sessão no canal criado:', error.message);
    removeSession(guild.id, createdChannel.id);
    await createdChannel.delete('Falha ao iniciar sessão').catch(() => {});
    await interaction.editReply({
      content: '✗ Criei o canal, mas não consegui montar a sessão nele. Tente novamente.'
    });
    return;
  }

  // Log e resposta final não devem impedir a sessão de funcionar mesmo se
  // falharem (ex: canal de logs sem permissão) — por isso ficam fora do
  // try/catch acima e só avisam no console.
  await logSessionCreated(guild, {
    userId: interaction.user.id,
    toolLabel: tool.label,
    areaId: cfg.areaId,
    mode
  }).catch((error) => console.error('⚠ Falha ao enviar log de sessão criada:', error.message));

  await interaction.editReply({
    content: `✓ Sessão criada: ${createdChannel}`
  });
}

module.exports = { handleSelectTool };
