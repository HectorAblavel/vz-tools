const { MessageFlags } = require('discord.js');
const { setGuildConfig, setToolOverride, getGuildConfig } = require('../utils/storage');
const { buildPanelContainer } = require('../components/panelBuilder');
const {
  buildPersonalizacaoContainer,
  buildOpcoesContainer
} = require('../components/adminBuilder');

async function refreshPostedPanelIfAny(interaction) {
  const cfg = getGuildConfig(interaction.guildId);
  if (!cfg.panelChannelId || !cfg.panelMessageId) return;

  try {
    const channel = await interaction.guild.channels.fetch(cfg.panelChannelId);
    const message = await channel.messages.fetch(cfg.panelMessageId);
    await message.edit({
      components: [buildPanelContainer(interaction.guildId)],
      flags: MessageFlags.IsComponentsV2
    });
  } catch {
    // O painel antigo pode ter sido apagado — ignora silenciosamente.
  }
}

async function handleTextosModal(interaction) {
  const titulo = interaction.fields.getTextInputValue('titulo');
  const placeholder = interaction.fields.getTextInputValue('placeholder');
  const descricao = interaction.fields.getTextInputValue('descricao');

  setGuildConfig(interaction.guildId, {
    panelTitle: titulo,
    placeholder,
    panelText: descricao
  });

  await refreshPostedPanelIfAny(interaction);

  await interaction.update({
    components: [buildPersonalizacaoContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

async function handleBannerThumbModal(interaction) {
  const banner = interaction.fields.getTextInputValue('banner').trim();
  const thumbnail = interaction.fields.getTextInputValue('thumbnail').trim();

  setGuildConfig(interaction.guildId, {
    bannerUrl: banner || null,
    thumbnailUrl: thumbnail || null
  });

  await refreshPostedPanelIfAny(interaction);

  await interaction.update({
    components: [buildPersonalizacaoContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

// Emoji customizado "<:nome:id>"/"<a:nome:id>", ou um único emoji unicode
// (com possíveis modificadores/ZWJ, ex: 🏳️‍🌈). Rejeita texto solto —
// um emoji inválido aqui quebraria .setEmoji() na hora de montar o menu,
// derrubando o painel inteiro na próxima abertura, não só este modal.
const CUSTOM_EMOJI_RE = /^<a?:\w{2,32}:\d{17,20}>$/;
const UNICODE_EMOJI_RE =
  /^(?:\p{Extended_Pictographic}|\p{Emoji_Presentation})(?:\uFE0F|\u200D(?:\p{Extended_Pictographic}|\p{Emoji_Presentation}))*$/u;

function isValidEmojiInput(value) {
  const trimmed = value.trim();
  return CUSTOM_EMOJI_RE.test(trimmed) || UNICODE_EMOJI_RE.test(trimmed);
}

async function handleToolEditModal(interaction, toolId) {
  const label = interaction.fields.getTextInputValue('label');
  const panelTitle = interaction.fields.getTextInputValue('panelTitle');
  const emoji = interaction.fields.getTextInputValue('emoji').trim();
  const menuDescription = interaction.fields.getTextInputValue('menuDescription');
  const formatosRaw = interaction.fields.getTextInputValue('formatosAceitos');

  if (!isValidEmojiInput(emoji)) {
    await interaction.reply({
      content:
        '✗ Emoji inválido. Use um emoji unicode (ex: 🔥) ou um emoji customizado ' +
        'no formato `<:nome:id>` (copie o emoji com `\\` na frente numa mensagem para ver o formato certo).',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  const formatosAceitos = formatosRaw
    .split(',')
    .map((f) => f.trim())
    .filter(Boolean)
    .map((f) => (f.startsWith('.') ? f : `.${f}`));

  if (formatosAceitos.length === 0) {
    await interaction.reply({
      content: '✗ Informe ao menos um formato aceito (ex: `.png, .jpg`).',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  setToolOverride(interaction.guildId, toolId, {
    label,
    panelTitle,
    emoji,
    menuDescription,
    formatosAceitos
  });

  await refreshPostedPanelIfAny(interaction);

  await interaction.update({
    components: [buildOpcoesContainer(interaction.guildId)],
    flags: MessageFlags.IsComponentsV2
  });
}

module.exports = {
  handleTextosModal,
  handleBannerThumbModal,
  handleToolEditModal
};
