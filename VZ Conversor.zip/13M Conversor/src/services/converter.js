const ffmpegPath = require('ffmpeg-static');
const ffmpeg = require('fluent-ffmpeg');
const sharp = require('sharp');
const path = require('path');

ffmpeg.setFfmpegPath(ffmpegPath);

function videoToGif(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .outputOptions([
        '-vf',
        'fps=15,scale=480:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse',
        '-loop',
        '0'
      ])
      .toFormat('gif')
      .on('end', () => resolve(outputPath))
      .on('error', reject)
      .save(outputPath);
  });
}

function compressMedia(inputPath, outputPath) {
  const ext = path.extname(inputPath).toLowerCase();

  return new Promise((resolve, reject) => {
    if (ext === '.gif') {
      ffmpeg(inputPath)
        .outputOptions(['-vf', 'fps=10,scale=360:-1:flags=lanczos'])
        .toFormat('gif')
        .on('end', () => resolve(outputPath))
        .on('error', reject)
        .save(outputPath);
      return;
    }

    ffmpeg(inputPath)
      .videoCodec('libx264')
      .outputOptions(['-crf', '30', '-preset', 'veryfast'])
      .audioCodec('aac')
      .audioBitrate('96k')
      .on('end', () => resolve(outputPath))
      .on('error', reject)
      .save(outputPath);
  });
}

function extractAudio(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .noVideo()
      .audioCodec('libmp3lame')
      .audioBitrate('192k')
      .on('end', () => resolve(outputPath))
      .on('error', reject)
      .save(outputPath);
  });
}

async function grayscaleImage(inputPath, outputPath) {
  const ext = path.extname(inputPath).toLowerCase();

  if (ext === '.gif') {
    return new Promise((resolve, reject) => {
      ffmpeg(inputPath)
        .outputOptions(['-vf', 'hue=s=0'])
        .toFormat('gif')
        .on('end', () => resolve(outputPath))
        .on('error', reject)
        .save(outputPath);
    });
  }

  await sharp(inputPath).grayscale().toFile(outputPath);
  return outputPath;
}

async function convert(kind, inputPath, outputPath) {
  switch (kind) {
    case 'video-to-gif':
      return videoToGif(inputPath, outputPath);
    case 'compress':
      return compressMedia(inputPath, outputPath);
    case 'extract-audio':
      return extractAudio(inputPath, outputPath);
    case 'grayscale':
      return grayscaleImage(inputPath, outputPath);
    default:
      throw new Error(`Tipo de conversão desconhecido: ${kind}`);
  }
}

module.exports = { convert };
