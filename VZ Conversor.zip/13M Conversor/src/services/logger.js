const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
const { getGuildConfig } = require('../utils/storage');

async function getLogChannel(guild) {
  const cfg = getGuildConfig(guild.id);
  if (!cfg.logChannelId) return null;
  try {
    const channel = await guild.channels.fetch(cfg.logChannelId);
    return channel;
  } catch {
    return null;
  }
}

async function sendLog(guild, container) {
  const logChannel = await getLogChannel(guild);
  if (!logChannel) return;
  await logChannel.send({
    components: [container],
    flags: MessageFlags.IsComponentsV2
  });
}

async function logSessionCreated(guild, { userId, toolLabel, areaId, mode }) {
  const container = new ContainerBuilder().addTextDisplayComponents(
    new TextDisplayBuilder().setContent('**— Sessão do Conversor criada**'),
    new TextDisplayBuilder().setContent(
      `Usuário: <@${userId}>\n` +
        `Opção: \`${toolLabel}\`\n` +
        `Área: <#${areaId}>\n` +
        `Modo: \`${mode}\``
    )
  );
  await sendLog(guild, container);
}

async function logSessionClosed(guild, { areaId, closedByUserId }) {
  // O fechamento automático por inatividade passa um texto fixo em vez de
  // um ID de usuário (ver inactivitySweep.js) — só transforma em menção
  // quando for de fato um ID numérico de usuário.
  const closedBy = /^\d{17,20}$/.test(closedByUserId)
    ? `<@${closedByUserId}>`
    : closedByUserId;

  const container = new ContainerBuilder().addTextDisplayComponents(
    new TextDisplayBuilder().setContent('⚿ **Sessão do Conversor fechada**'),
    new TextDisplayBuilder().setContent(
      `Área: <#${areaId}>\n` + `Fechada por: ${closedBy}`
    )
  );
  await sendLog(guild, container);
}

module.exports = { logSessionCreated, logSessionClosed };
