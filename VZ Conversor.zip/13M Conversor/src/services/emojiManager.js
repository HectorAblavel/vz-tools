const fs = require('fs');
const path = require('path');

const MANIFEST_PATH = path.join(__dirname, '..', '..', 'assets', 'emojis', 'manifest.json');
const STATE_PATH = path.join(__dirname, '..', '..', 'data', 'emojis.json');

const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));

function readState() {
  if (!fs.existsSync(STATE_PATH)) return {};
  try {
    return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
  } catch {
    return {};
  }
}

function writeState(state) {
  fs.mkdirSync(path.dirname(STATE_PATH), { recursive: true });
  fs.writeFileSync(STATE_PATH, JSON.stringify(state, null, 2));
}

// Estado em memória usado pelo helper getEmoji() (utils/emojis.js).
let installed = readState();

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function discordRequest(token, urlPath, init = {}) {
  const response = await fetch(`https://discord.com/api/v10${urlPath}`, {
    ...init,
    headers: {
      Authorization: `Bot ${token}`,
      'Content-Type': 'application/json',
      ...(init.headers || {})
    }
  });
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { message: text };
  }
  if (response.status === 429) {
    const retry = Number(data.retry_after || 1.5) * 1000;
    await sleep(Math.max(1000, retry));
    return discordRequest(token, urlPath, init);
  }
  if (!response.ok) {
    throw new Error(data.message || `Discord HTTP ${response.status}`);
  }
  return data;
}

/**
 * Instala (ou verifica) os emojis da aplicação e salva os IDs retornados
 * pelo Discord em data/emojis.json. Roda uma vez, no início (clientReady).
 * Se algo falhar, o bot continua funcionando normalmente usando os
 * emojis unicode de fallback definidos no manifest.
 */
async function syncEmojis(client, token) {
  const applicationId = client.application?.id;
  if (!applicationId) {
    console.warn('⚠ Não consegui identificar o Application ID para sincronizar os emojis.');
    return;
  }

  console.log(`⏻ Sincronizando ${manifest.length} emojis da aplicação...`);

  let remote;
  try {
    remote = await discordRequest(token, `/applications/${applicationId}/emojis`);
  } catch (error) {
    console.error('✗ Não consegui consultar os emojis existentes na aplicação:', error.message);
    console.error('→ O bot vai continuar usando os emojis unicode de fallback.');
    return;
  }

  const remoteList = Array.isArray(remote) ? remote : remote.items || [];
  const remoteByName = new Map(remoteList.map((e) => [e.name, e]));

  const state = {};
  let created = 0;
  let reused = 0;
  let failed = 0;

  for (const item of manifest) {
    const existing = remoteByName.get(item.name);
    if (existing) {
      state[item.semantic] = { id: existing.id, name: existing.name };
      reused++;
      continue;
    }

    try {
      const filePath = path.join(__dirname, '..', '..', 'assets', 'emojis', item.file);
      const bytes = fs.readFileSync(filePath);
      const image = `data:image/png;base64,${bytes.toString('base64')}`;
      const createdEmoji = await discordRequest(token, `/applications/${applicationId}/emojis`, {
        method: 'POST',
        body: JSON.stringify({ name: item.name, image })
      });
      state[item.semantic] = { id: createdEmoji.id, name: createdEmoji.name };
      created++;
      await sleep(350); // evita rate limit ao criar vários em sequência
    } catch (error) {
      console.error(`✗ Falha ao instalar o emoji "${item.name}":`, error.message);
      failed++;
    }
  }

  installed = state;
  writeState(state);

  console.log(
    `✓ Emojis sincronizados: ${created} criados, ${reused} já existentes${
      failed ? `, ${failed} falharam (usarão fallback unicode)` : ''
    }.`
  );
}

/**
 * Retorna o identificador pronto para .setEmoji():
 * - "<:nome:id>" se o emoji já foi instalado nesta aplicação
 * - o emoji unicode de fallback, caso contrário (bot nunca quebra)
 */
function getEmoji(semantic) {
  const item = manifest.find((m) => m.semantic === semantic);
  const found = installed[semantic];
  if (found) return `<:${found.name}:${found.id}>`;
  return item ? item.fallback : '❓';
}

module.exports = { syncEmojis, getEmoji };
