const { getAllSessionEntries, removeSession } = require('../utils/storage');
const { closeSession } = require('../handlers/button');

const INACTIVITY_MINUTES = Number(process.env.INACTIVITY_MINUTES) || 15;
const INACTIVITY_MS = INACTIVITY_MINUTES * 60 * 1000;
const SWEEP_INTERVAL_MS = 2 * 60 * 1000; // checa a cada 2 minutos

async function sweepOnce(client, guildId) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) return;

  const entries = getAllSessionEntries(guildId);
  const now = Date.now();

  for (const { channelId, session } of entries) {
    const lastActivity = session.lastActivity || 0;
    if (now - lastActivity < INACTIVITY_MS) continue;

    try {
      const channel = await guild.channels.fetch(channelId);
      if (!channel) {
        removeSession(guildId, channelId);
        continue;
      }
      await closeSession(guild, channel, session, 'Automático (inatividade)');
    } catch {
      // Canal/thread já pode ter sido apagado manualmente
      removeSession(guildId, channelId);
    }
  }
}

function startInactivitySweep(client, guildId) {
  console.log(
    `◷ Fechamento automático por inatividade ativo (${INACTIVITY_MINUTES} min sem atividade).`
  );
  setInterval(() => {
    sweepOnce(client, guildId).catch((err) =>
      console.error('Erro na varredura de inatividade:', err)
    );
  }, SWEEP_INTERVAL_MS);
}

module.exports = { startInactivitySweep };
