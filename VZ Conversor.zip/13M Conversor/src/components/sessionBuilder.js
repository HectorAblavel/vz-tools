const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle
} = require('discord.js');
const { getEmoji } = require('../services/emojiManager');

function buildSessionContainer({ tool, userId, breadcrumb }) {
  const container = new ContainerBuilder();

  if (breadcrumb) {
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# ${breadcrumb}`)
    );
  }

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(`## ↻ ${tool.panelTitle}`)
  );

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `<@${userId}>, envie o arquivo solicitado aqui neste canal.`
    )
  );

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      '**Arquivo esperado**\n' +
        `Formatos aceitos: ${tool.formatosAceitos
          .map((f) => `\`${f}\``)
          .join(', ')}\n` +
        `Tamanho recomendado: \`${tool.tamanhoRecomendado}\``
    )
  );

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      '**Como vai funcionar**\n' +
        'Assim que você enviar o arquivo, eu vou mostrar uma mensagem de processamento.\n' +
        'Quando terminar, o arquivo convertido será enviado aqui mesmo.\n' +
        'Se não for possível converter, eu vou explicar o motivo.'
    )
  );

  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  const closeButton = new ButtonBuilder()
    .setCustomId('conversor:close-session')
    .setLabel('Fechar')
    .setEmoji(getEmoji('lock'))
    .setStyle(ButtonStyle.Danger);

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(closeButton)
  );

  return container;
}

module.exports = { buildSessionContainer };
