const {
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ChannelSelectMenuBuilder,
  ChannelType
} = require('discord.js');

const { getGuildConfig, getEffectiveTools } = require('../utils/storage');
const { getEmoji } = require('../services/emojiManager');

function breadcrumb(text) {
  return new TextDisplayBuilder().setContent(`-# ${text}`);
}

function modoTexto(areaType) {
  return areaType === 'category' ? 'Canal privado' : 'Tópico privado';
}

// ── Tela principal: Conversor ─────────────────────
function buildHomeContainer(guildId) {
  const cfg = getGuildConfig(guildId);
  const tools = getEffectiveTools(guildId);

  const container = new ContainerBuilder();
  container.addTextDisplayComponents(
    breadcrumb('Conversor')
  );
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('## ↻ Painel Conversor'),
    new TextDisplayBuilder().setContent(
      'Configure e envie um painel público para membros criarem uma área privada e anexarem arquivos.'
    )
  );
  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  const categoriaTexto = cfg.areaId ? `<#${cfg.areaId}>` : '`Não configurado`';
  const logsTexto = cfg.logChannelId ? `<#${cfg.logChannelId}>` : '`Não configurado`';

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      '**Resumo**\n' +
        `Modo de abertura: \`${modoTexto(cfg.areaType)}\`\n` +
        `Categoria dos canais: ${categoriaTexto}\n` +
        `Canal de logs: ${logsTexto}\n` +
        `Opções ativas: \`${Object.keys(tools).length}\``
    )
  );
  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('botconfig:enviar-painel')
      .setLabel('Enviar Painel Aqui')
      .setEmoji(getEmoji('plus'))
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('botconfig:personalizar')
      .setLabel('Personalizar')
      .setEmoji(getEmoji('wand'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('botconfig:usar-canal')
      .setLabel(cfg.areaType === 'category' ? 'Usar Tópico' : 'Usar Canal')
      .setEmoji(getEmoji('reload'))
      .setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('botconfig:fechar')
      .setLabel('Voltar')
      .setEmoji(getEmoji('back'))
      .setStyle(ButtonStyle.Secondary)
  );

  container.addActionRowComponents(row1, row2);
  return container;
}

// ── Tela: Personalizar ──────────────────────────────────────────────────────
function buildPersonalizacaoContainer(guildId) {
  const cfg = getGuildConfig(guildId);

  const container = new ContainerBuilder();
  container.addTextDisplayComponents(
    breadcrumb('Conversor › Personalizar')
  );
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('## ⚙ Personalização'),
    new TextDisplayBuilder().setContent(
      'Ajuste a aparência, opções, logs e categoria do Conversor.'
    )
  );
  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      '**Aparência**\n' +
        `Título: \`${cfg.panelTitle}\`\n` +
        `Placeholder: \`${cfg.placeholder}\`\n` +
        `Banner: \`${cfg.bannerUrl ? 'Configurado' : 'Não configurado'}\`\n` +
        `Thumbnail: \`${cfg.thumbnailUrl ? 'Configurada' : 'Não configurada'}\``
    )
  );

  const categoriaTexto = cfg.areaId ? `<#${cfg.areaId}>` : '`Não configurado`';
  const logsTexto = cfg.logChannelId ? `<#${cfg.logChannelId}>` : '`Não configurado`';

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      '**Canais**\n' + `Logs: ${logsTexto}\n` + `Categoria: ${categoriaTexto}`
    )
  );

  if (cfg.bannerUrl) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(cfg.bannerUrl)
      )
    );
  }

  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('botconfig:textos')
      .setLabel('Textos')
      .setEmoji(getEmoji('edit'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('botconfig:banner-thumb')
      .setLabel('Banner/Thumb')
      .setEmoji(getEmoji('image'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('botconfig:opcoes')
      .setLabel('Opções')
      .setEmoji(getEmoji('settings'))
      .setStyle(ButtonStyle.Secondary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('botconfig:logs-categoria')
      .setLabel('Logs/Categoria')
      .setEmoji(getEmoji('folder'))
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('botconfig:resetar')
      .setLabel('Resetar')
      .setEmoji(getEmoji('delete'))
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('botconfig:home')
      .setLabel('Voltar')
      .setEmoji(getEmoji('back'))
      .setStyle(ButtonStyle.Secondary)
  );

  container.addActionRowComponents(row1, row2);
  return container;
}

// ── Tela: Opções do Conversor ────────────────────────────────────────────
function buildOpcoesContainer(guildId) {
  const tools = getEffectiveTools(guildId);

  const container = new ContainerBuilder();
  container.addTextDisplayComponents(
    breadcrumb('Conversor › Personalizar › Opções')
  );
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('## ⚙ Opções do Conversor'),
    new TextDisplayBuilder().setContent(
      'Selecione qual opção deseja editar. Você pode mudar label, título, emoji, descrição e formatos.'
    )
  );
  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  const select = new StringSelectMenuBuilder()
    .setCustomId('botconfig:select-tool-edit')
    .setPlaceholder('Selecione uma opção para editar')
    .addOptions(
      Object.values(tools).map((t) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(t.label)
          .setDescription(t.menuDescription)
          .setValue(t.id)
          .setEmoji(t.emoji)
      )
    );

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(select)
  );

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('botconfig:personalizar')
        .setLabel('Voltar')
        .setEmoji(getEmoji('back'))
        .setStyle(ButtonStyle.Secondary)
    )
  );

  return container;
}

// ── Tela: Logs/Categoria ─────────────────────────────────────────────────
function buildLogsCategoriaContainer(guildId) {
  const container = new ContainerBuilder();
  container.addTextDisplayComponents(
    breadcrumb(
      'Conversor › Personalizar › Logs/Categoria'
    )
  );
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('## ▤ Logs & Categoria'),
    new TextDisplayBuilder().setContent(
      'Escolha o canal de logs e onde as sessões (tópicos ou canais) serão criadas.'
    )
  );
  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  const logSelect = new ChannelSelectMenuBuilder()
    .setCustomId('botconfig:select-log-channel')
    .setPlaceholder('Selecione o canal de logs')
    .addChannelTypes(ChannelType.GuildText);

  const areaSelect = new ChannelSelectMenuBuilder()
    .setCustomId('botconfig:select-area-channel')
    .setPlaceholder('Selecione a categoria (canais) ou canal (tópicos)')
    .addChannelTypes(ChannelType.GuildCategory, ChannelType.GuildText);

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(logSelect),
    new ActionRowBuilder().addComponents(areaSelect)
  );

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('botconfig:personalizar')
        .setLabel('Voltar')
        .setEmoji(getEmoji('back'))
        .setStyle(ButtonStyle.Secondary)
    )
  );

  return container;
}

// ── Tela: confirmação de reset (melhoria 1) ─────────────────────────────
function buildResetConfirmContainer() {
  const container = new ContainerBuilder();
  container.addTextDisplayComponents(
    breadcrumb(
      'Conversor › Personalizar › Resetar'
    )
  );
  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent('## ⌦ Resetar configurações?'),
    new TextDisplayBuilder().setContent(
      'Isso vai apagar título, descrição, banner, thumbnail, opções personalizadas, ' +
        'canal de logs e área configurados — **essa ação não pode ser desfeita**.\n\n' +
        'Sessões abertas no momento não serão afetadas.'
    )
  );
  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('botconfig:resetar-confirmar')
        .setLabel('Confirmar Reset')
        .setEmoji(getEmoji('warn'))
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId('botconfig:resetar-cancelar')
        .setLabel('Cancelar')
        .setEmoji(getEmoji('wrong'))
        .setStyle(ButtonStyle.Secondary)
    )
  );

  return container;
}

module.exports = {
  buildHomeContainer,
  buildPersonalizacaoContainer,
  buildOpcoesContainer,
  buildLogsCategoriaContainer,
  buildResetConfirmContainer
};
