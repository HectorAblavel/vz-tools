const {
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder
} = require('discord.js');

const { getGuildConfig, getEffectiveTools } = require('../utils/storage');

function buildPanelContainer(guildId) {
  const cfg = getGuildConfig(guildId);
  const tools = getEffectiveTools(guildId);
  const container = new ContainerBuilder();

  // Cabeçalho (com thumbnail ao lado, se configurada)
  if (cfg.thumbnailUrl) {
    const header = new SectionBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`## ↻ ${cfg.panelTitle}`),
        new TextDisplayBuilder().setContent(cfg.panelText)
      )
      .setThumbnailAccessory(new ThumbnailBuilder().setURL(cfg.thumbnailUrl));
    container.addSectionComponents(header);
  } else {
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`## ↻ ${cfg.panelTitle}`),
      new TextDisplayBuilder().setContent(cfg.panelText)
    );
  }

  // Lista de ferramentas
  const toolLines = Object.values(tools)
    .map((t) => `${t.emoji} **${t.label}**: ${t.menuDescription}.`)
    .join('\n');

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      `**Ferramentas Disponíveis:**\n${toolLines}`
    )
  );

  container.addTextDisplayComponents(
    new TextDisplayBuilder().setContent(
      '**Como funciona?**\n' +
        '1. Escolha o tipo de conversão no menu.\n' +
        '2. Um canal ou tópico privado será criado para você.\n' +
        '3. Envie o arquivo solicitado e aguarde o processamento.'
    )
  );

  // Banner (se configurado)
  if (cfg.bannerUrl) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(cfg.bannerUrl)
      )
    );
  }

  container.addSeparatorComponents(
    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
  );

  // Select menu
  const select = new StringSelectMenuBuilder()
    .setCustomId('conversor:select-tool')
    .setPlaceholder(cfg.placeholder)
    .addOptions(
      Object.values(tools).map((t) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(t.label)
          .setDescription(t.menuDescription)
          .setValue(t.id)
          .setEmoji(t.emoji)
      )
    );

  container.addActionRowComponents(
    new ActionRowBuilder().addComponents(select)
  );

  return container;
}

module.exports = { buildPanelContainer };
