# Conversor de Arquivos — Bot Discord (Components V2)

Bot privado para um único servidor, com:

- Painel público em **Components V2** (título, descrição, lista de ferramentas, banner, menu de seleção).
- Ao escolher uma ferramenta, o bot cria automaticamente uma **thread privada** (Modo: Tópico) ou um **canal privado** dentro de uma categoria (Modo: Canal).
- Botão **Fechar** dentro da sessão (apaga o canal ou tópico).
- Log de sessão criada e sessão fechada em um canal de logs configurável.
- Comando `/botconfig` com painel administrativo navegável:
  `Painel → Administração → Conversor → Personalizar → (Textos / Banner-Thumb / Opções / Logs-Categoria)`.
- Conversão real de arquivos com `ffmpeg` e `sharp`: vídeo → GIF, compressão, extração de áudio, preto e branco.

## Melhorias incluídas

1. **Confirmação de reset** — clicar em "Resetar" agora abre uma tela de confirmação
   (`Confirmar Reset` / `Cancelar`) antes de apagar qualquer configuração.
2. **Uma sessão por usuário** — se o usuário já tem uma sessão aberta, o bot avisa e aponta
   para o canal/tópico existente em vez de criar outro.
3. **Fechamento automático por inatividade** — sessões sem nenhuma mensagem do dono por
   `INACTIVITY_MINUTES` (padrão: 15 min) são fechadas sozinhas, com log
   `Fechada por: Automático (inatividade)`.
4. **Limite de tamanho de arquivo** — arquivos acima de 25MB são recusados antes de baixar/processar,
   evitando travar o bot.
5. **Múltiplos anexos** — se o usuário mandar vários arquivos na mesma mensagem, todos são
   processados, um de cada vez, com resposta individual para cada um.
6. **Bot privado** — só funciona no servidor definido em `GUILD_ID`. Se for adicionado a outro
   servidor, ele sai sozinho automaticamente, e ignora qualquer interação/mensagem fora desse servidor.

## 1. Instalar dependências

```bash
cd conversor-bot
npm install
```

## 2. Configurar credenciais (duas opções — escolha uma)

**Opção A — `.env`** (copie `.env.example` para `.env`):

```
DISCORD_TOKEN=seu_token_do_bot
CLIENT_ID=id_da_aplicacao
GUILD_ID=id_do_seu_servidor
INACTIVITY_MINUTES=15
```

**Opção B — `config.json`** (copie `config.json.example` para `config.json`):

```json
{
  "token": "seu_token_do_bot",
  "clientId": "id_da_aplicacao",
  "guildId": "id_do_seu_servidor"
}
```

Se as duas existirem, o `.env` tem prioridade. `GUILD_ID`/`guildId` é **obrigatório** — é ele que
trava o bot no seu servidor.

No [Discord Developer Portal](https://discord.com/developers/applications), na aba **Bot**, ative:
- **Message Content Intent**
- **Server Members Intent**

## 3. Slash commands (automático)

O bot registra o `/botconfig` sozinho toda vez que liga — não precisa rodar nada manualmente.
Se por algum motivo ele não aparecer no Discord, confira:

- O bot foi convidado ao servidor com o escopo **`applications.commands`** (não só `bot`)?
  Gere o link em Developer Portal → sua aplicação → **OAuth2 → URL Generator**, marque
  `bot` **e** `applications.commands`, use esse link pra convidar/reconvidar o bot.
- O `CLIENT_ID` no `.env`/`config.json` é o mesmo ID da aplicação (aparece em **General Information**)?
- Depois de convidar de novo, reinicie o bot uma vez. O comando costuma aparecer na hora
  (é registrado por servidor, não precisa esperar propagação global).

Se preferir registrar manualmente por fora, ainda existe `npm run deploy` disponível.

## 4. Rodar o bot

```bash
npm start
```

## 5. Configurar no servidor

1. Rode `/botconfig` (precisa de permissão **Gerenciar Servidor**).
2. Em **Logs/Categoria**, escolha o canal de logs e a área (categoria → modo Canal, canal de texto → modo Tópico).
   O botão **Usar Canal/Usar Tópico** na tela inicial alterna rapidamente entre os dois modos.
3. Em **Personalizar → Textos**, defina título, placeholder e descrição do painel.
4. Em **Personalizar → Banner/Thumb**, defina as URLs de imagem (opcional).
5. Em **Personalizar → Opções**, edite label, título interno, emoji, descrição e formatos aceitos de cada ferramenta.
6. Volte ao menu inicial e clique em **Enviar Painel Aqui** para postar o painel público no canal atual.

## 6. Permissões do bot no servidor

- Ver Canal, Enviar Mensagens, Anexar Arquivos, Ler Histórico de Mensagens
- Gerenciar Canais (modo Canal) e/ou Criar Tópicos Privados / Gerenciar Tópicos (modo Tópico)

## Estrutura do projeto

```
config.json.example          # alternativa ao .env
src/
  index.js                    # entry point, liga tudo + trava de servidor privado
  deploy-commands.js           # registra /botconfig (só no GUILD_ID)
  commands/config.js           # slash command /botconfig
  components/
    panelBuilder.js              # painel público (Components V2)
    adminBuilder.js               # todas as telas do /botconfig (incl. confirmação de reset)
    sessionBuilder.js              # painel dentro da thread/canal criado
  handlers/
    selectMenu.js                  # cria a thread/canal (bloqueia sessão duplicada)
    button.js                       # botão "Fechar" (lógica reaproveitada no auto-close)
    adminButton.js                   # navegação do /botconfig
    adminSelect.js                    # selects (editar opção / escolher canais)
    adminModal.js                      # submissão dos modais de edição
    messageCreate.js                    # processa anexos (limite de tamanho + múltiplos arquivos)
  services/
    converter.js                         # conversões reais (ffmpeg/sharp)
    logger.js                             # logs de sessão criada/fechada
    inactivitySweep.js                     # fechamento automático por inatividade
  utils/
    env.js                                  # carrega .env ou config.json
    storage.js                               # config por servidor (JSON local)
    tools.js                                  # definição padrão das 4 ferramentas
```

Toda a sintaxe foi validada com `node --check` em cada arquivo. Os pacotes não puderam ser
baixados neste ambiente (sem acesso à internet), então rode `npm install` normalmente na sua
máquina — não há nenhum erro de código, apenas dependências externas a instalar.
